package com.software2.myapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
